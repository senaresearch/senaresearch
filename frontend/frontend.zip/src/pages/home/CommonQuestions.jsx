import React from 'react'

const CommonQuestions = () => {
  return (
    <div>CommonQuestions</div>
  )
}

export default CommonQuestions